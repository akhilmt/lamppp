<?php
class Ctrl_test extends CI_Controller
	{
	public function __construct()
		{
		parent::__construct();
        $this->load->helper('url');

		}
	

	public function get()
		{
		$name=$_REQUEST['name'];
		echo $name;
		}
	 public function index()
		{
/*	public function set($a=0,$b=0,$i=0)
	{
	switch ($i) {
    case 0:
        echo $a+$b;
        break;
    case 1:
        echo $a*$b;
        break;
    case 2:
        echo $a/$b;
        break;
}

}*/
$this->load->model('Mdl_test');
		$this->Mdl_test->f2();
$a['name']='sam';
$this->load->view('v1',$a);
}
}
?>
