<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="<?php echo base_url();?>external/style.css">
<script type="text/javascript" src="<?php echo base_url();?>external/test.js">
</script>
</head>
<body><?php
echo "name is $name";
?>
<form type='post' action="<?php echo base_url();?>/index.php/Ctrl_test/get">
<input type="text" name='name' placeholder="name">
<input type="submit" value="FIRE">
</form>
</body>
</html>
