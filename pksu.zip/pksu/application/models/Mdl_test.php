<?php
class Mdl_test extends CI_Model
{
public function f2()
{
echo "First model";
}
}
?>
